package Exercises1_2_EvaOgandzhanian;

public class DataTypes_and_variables {

    public static void  main(String[] args) {

        String initial = "EO";
        int populationGermany = 83000000;
        long populationEarth = 7800000000L;
        boolean isDaytime = true;
        float marioGomezGoalStrike = 0.54f;
        byte javaProgramLengthWeeks = 16;
        double piValue = 3.14159265359;

        System.out.println("Initials: " + initial + ". Population in Germany: " + populationGermany + ". Population on Earth: " + populationEarth + ". Is currently daytime? " + isDaytime + ". Goal strike quote of Mario Gomez at Bayern München: " + marioGomezGoalStrike + ". Length of the Java program in weeks: " + javaProgramLengthWeeks + ". The mathematical number PI: " + piValue);

        }

    }



