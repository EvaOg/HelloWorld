package Exercises1_2_EvaOgandzhanian;

import java.util.Scanner;

public class Truangle {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("How large should the triangles be? ");
        int size = Integer.parseInt(sc.nextLine());

        System.out.print("How many triangles would you like? ");
        int amount = Integer.parseInt(sc.nextLine());
        //Äußere Schleife für Anzahl der Dreiecke
        for (int i = 0; i < amount; i++) {
            //Innere Schleife für das jeweilige Dreieck, über die repeat Methode kann man die Ausgabe direkt mit println verbinden
            for (int j = 0; j <= size; j++) {
                System.out.println("*".repeat(j));
            }



            System.out.println("It's christmas time! Order your christmas tree right here!");
            System.out.print("How big should the tree be? ");
            int size2 = Integer.parseInt(sc.nextLine());
            // Using a for loop for the upper part of the tree
            for (int j = 1; j <= size; j++) {
                System.out.println(" ".repeat(size2 - j) + "*".repeat((j * 2) - 1));
            }
            // Printing the trunk of the tree
            System.out.println(" ".repeat(size2 - 1) + "I");
        }
    }
}